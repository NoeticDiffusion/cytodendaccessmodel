E025 local release candidate — prepared 2026-09-26

This bundle contains the registered E025 plan and manifests, runner and renderer, frozen E024 model-definition dependency, E025 outputs, figure assets, manuscript sources, and compiled manuscript/supporting PDFs.

Status: LOCAL STAGING COPY ONLY. It has not been uploaded to a repository and has no DOI. Before public deposit/submission, create a versioned archive, add its persistent identifier to the manuscript and S4, rebuild the final PDFs, and replace the relevant PDFs in this bundle. The article currently identifies the older Zenodo release as predating E025.

The E025 outcome-blind plan and input hashes are included. The result files preserve development, validation, and locked holdout outputs.
